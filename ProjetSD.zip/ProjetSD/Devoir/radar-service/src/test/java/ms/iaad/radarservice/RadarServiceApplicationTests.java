package ms.iaad.radarservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RadarServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
